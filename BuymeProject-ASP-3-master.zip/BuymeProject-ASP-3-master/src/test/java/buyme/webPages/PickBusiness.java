package buyme.webPages;

import org.openqa.selenium.By;
import org.testng.Assert;
import buyme.base.BasePage;
import org.testng.annotations.Test;

public class PickBusiness extends BasePage {

   String PickBusinessUrl = "https://buyme.co.il/search?budget=3&category=337&region=11";

   // public void assertWebsiteUrl(String element) {
  //      Assert.assertEquals(element, PickBusinessUrl);

   // public void pickBusinessAndMount() {
   //     clickElement(By.xpath("//*[@id=\"ember1632\"]"));
     //   sendKeysToElement(By.cssSelector("input[placeholder=\"הכנס סכום\"]"), "200");
    //    clickElement(By.cssSelector("button[gtm=\"בחירה\"]"));
    }



